//
//  SVCWonderfulVideoViewController.h
//  SmartValleyCloudSeeding
//
//  Created by 华安 on 2018/7/9.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlainTableViewController.h"

@interface SVCWonderfulVideoViewController : PlainTableViewController

@end
