//
//  SVCMoviePlayerModel.m
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2019/1/25.
//  Copyright © 2019 SoWhat. All rights reserved.
//

#import "SVCMoviePlayerModel.h"

@implementation SVCMoviePlayerModel

@end
