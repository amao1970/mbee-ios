//
//  SVCliveViewCell.h
//  SmartValleyCloudSeeding
//
//  Created by xumin on 2018/6/16.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVCliveViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageViewICon;

@property (weak, nonatomic) IBOutlet UILabel *titleLa;

@property (weak, nonatomic) IBOutlet UILabel *contentLa;
@property (weak, nonatomic) IBOutlet UIButton *numButton;


@end
