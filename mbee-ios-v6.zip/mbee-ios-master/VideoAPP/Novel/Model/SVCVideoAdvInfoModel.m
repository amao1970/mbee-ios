//
//  SVCVideoAdvInfoModel.m
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2018/12/10.
//  Copyright © 2018 SoWhat. All rights reserved.
//

#import "SVCVideoAdvInfoModel.h"

@implementation SVCVideoAdvInfoModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
