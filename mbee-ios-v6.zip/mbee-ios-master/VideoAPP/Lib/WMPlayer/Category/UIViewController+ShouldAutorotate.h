//
//  UIViewController+ShouldAutorotate.h
//  PlayerDemo
//
//  Created by zhengwenming on 2018/6/10.
//  Copyright © 2018年 DS-Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (ShouldAutorotate)

@end

@interface UITabBarController (ShouldAutorotate)

@end

@interface UINavigationController (ShouldAutorotate)<UIGestureRecognizerDelegate>

@end

@interface UIAlertController (ShouldAutorotate)

@end
