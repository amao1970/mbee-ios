//
//  SVCMidCollectionViewCell.h
//  SmartValleyCloudSeeding
//
//  Created by xumin on 2018/6/12.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVCMidCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *plusLabel;

@property (weak, nonatomic) IBOutlet UILabel *numLabel;


@end
