//
//  SVCOnbordModel.h
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2018/11/22.
//  Copyright © 2018 SoWhat. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SVCOnbordModel : NSObject
@property (nonatomic,copy) NSString *ID;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *link;
@property (nonatomic,copy) NSString *adtext;
@property (nonatomic,copy) NSString *position_id;
@property (nonatomic,copy) NSString *tui;
@property (nonatomic,copy) NSString *position_name;
@end

NS_ASSUME_NONNULL_END
