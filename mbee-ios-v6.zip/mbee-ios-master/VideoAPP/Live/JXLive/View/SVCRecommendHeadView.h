//
//  SVCRecommendHeadView.h
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2019/1/21.
//  Copyright © 2019 SoWhat. All rights reserved.
//

#import "JXView.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVCRecommendHeadView : JXView

@property (strong, nonatomic) IBOutlet UILabel *playerNum;
@property (strong, nonatomic) IBOutlet UILabel *subtitleLab;
@property (strong, nonatomic) IBOutlet UILabel *titleLab;


@end

NS_ASSUME_NONNULL_END
