//
//  SVCInvitionModel.m
//  SmartValleyCloudSeeding
//
//  Created by 华安 on 2018/8/20.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import "SVCInvitionModel.h"

@implementation SVCInvitionModel

@end
