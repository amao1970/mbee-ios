//
//  SVCInvitionModel.h
//  SmartValleyCloudSeeding
//
//  Created by 华安 on 2018/8/20.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SVCInvitionModel : NSObject

@property(nonatomic, copy) NSString *intive_code; /**<<#属性#> */

@property(nonatomic, copy) NSString *promotion_link; /**<属性
                                                   */

@property(nonatomic, copy) NSString *promotion_desc; /**<属性 */

@property(nonatomic, copy) NSString *promotion_intro; /**<<#属性#> */

@end
