//
//  CollectionHeaderAndFooterView.m
//  collectionView
//
//  Created by 王双龙 on 2017/10/18.
//  Copyright © 2017年 王双龙. All rights reserved.
//

#import "CollectionHeaderAndFooterView.h"

@implementation CollectionHeaderAndFooterView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
