//
//  JXProductModel.m
//  MovieApp
//
//  Created by admxjx on 2019/4/19.
//

#import "JXProductModel.h"

@implementation JXProductModel

@end
