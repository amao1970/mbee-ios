//
//  Xuebei
//
//  Created by maceasy on 15/11/25.
//  Copyright © 2015年 macHY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WSYToastView : UIView

+ (instancetype)toastWithString:(NSString *)string;
- (void)finish;

@end
