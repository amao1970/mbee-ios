//
//  SVCinvateFriendsViewController.h
//  SmartValleyCloudSeeding
//
//  Created by 鹏张 on 2018/6/10.
//  Copyright © 2018年 SoWhat. All rights reserved.
//



@interface SVCinvateFriendsViewController : SVCBaseViewController
@property (nonatomic , copy)NSString *type;
@end
