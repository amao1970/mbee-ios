//
//  JXPlayBackViewController.h
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2019/1/17.
//  Copyright © 2019 SoWhat. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JXPlayBackViewController : SVCBaseViewController

@end

NS_ASSUME_NONNULL_END
