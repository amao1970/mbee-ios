//
//  QNTwoCodeTool.h
//  DeJiaAssistant
//
//  Created  on 15/12/8.
//  Copyright © 2015年 Science & Technology Development Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QNTwoCodeTool : NSObject

+ (UIImage *)createNonInterpolatedUIImageFormCIImage:(NSString *)url withSize:(CGFloat) size;

@end
