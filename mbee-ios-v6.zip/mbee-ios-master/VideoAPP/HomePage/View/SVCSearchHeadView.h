//
//  SVCSearchHeadView.h
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2019/1/24.
//  Copyright © 2019 SoWhat. All rights reserved.
//

#import "JXView.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVCSearchHeadView : JXView

@end

NS_ASSUME_NONNULL_END
