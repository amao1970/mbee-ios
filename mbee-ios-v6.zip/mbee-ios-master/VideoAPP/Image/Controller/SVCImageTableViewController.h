//
//  SVCImageTableViewController.h
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2018/12/4.
//  Copyright © 2018 SoWhat. All rights reserved.
//

#import "PlainTableViewController.h"
#import "PlainTableViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface SVCImageTableViewController : PlainTableViewController
- (instancetype)initWithCategoryID:(NSString *)ID;
@end

NS_ASSUME_NONNULL_END
