//
//  JXSearchHotListCell.h
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2019/1/13.
//  Copyright © 2019 SoWhat. All rights reserved.
//

#import "JXCollectionViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface JXSearchHotListCell : JXCollectionViewCell
@property (strong, nonatomic) IBOutlet UILabel *titleLab;
@property (strong, nonatomic) IBOutlet UIView *line;

@end

NS_ASSUME_NONNULL_END
