//
//  JXKindModel.m
//  MovieApp
//
//  Created by admxjx on 2019/4/19.
//

#import "JXKindModel.h"

@implementation JXKindModel

@end
