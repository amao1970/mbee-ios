//
//  SVCLoadingView.h
//  SmartValleyCloudSeeding
//
//  Created by xumin on 2018/6/21.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVCLoadingView : UIView


-(void)loadViewRemove;

@end
