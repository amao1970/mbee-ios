//
//  UILabel+Others.h
//  isWater
//
//  Created by hxisWater on 15/8/21.
//  Copyright (c) 2015年 HX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Others)
-(void)addparagraphStyleWithCGFloat:(CGFloat)lineSpace;

-(void)addNSUnderlinePatternWithRnage:(NSRange )range;


@end
