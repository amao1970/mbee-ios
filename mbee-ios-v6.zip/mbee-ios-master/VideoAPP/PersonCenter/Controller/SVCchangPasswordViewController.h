//
//  SVCchangPasswordViewController.h
//  SmartValleyCloudSeeding
//
//  Created by 鹏张 on 2018/6/8.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVCchangPasswordViewController : SVCBaseViewController

@property (nonatomic , copy)NSString *type;

@end
