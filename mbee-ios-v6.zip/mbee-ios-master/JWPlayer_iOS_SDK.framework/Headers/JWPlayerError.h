//
//  JWPlayerError.h
//  JWPlayer-iOS-SDK
//
//  Created by karim on 5/15/18.
//  Copyright © 2018 JWPlayer. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JWPlayerError : NSError

@end
