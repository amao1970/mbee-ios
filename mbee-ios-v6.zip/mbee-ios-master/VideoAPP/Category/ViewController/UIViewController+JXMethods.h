//
//  UIViewController+JXMethods.h
//  publicRedPacket
//
//  Created by admso on 2018/10/9.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (JXMethods)

-(void)setBackImgWithImg:(NSString*)imageStr;

@end

NS_ASSUME_NONNULL_END
