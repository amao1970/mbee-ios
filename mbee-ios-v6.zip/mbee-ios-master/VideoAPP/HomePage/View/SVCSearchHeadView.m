//
//  SVCSearchHeadView.m
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2019/1/24.
//  Copyright © 2019 SoWhat. All rights reserved.
//

#import "SVCSearchHeadView.h"

@implementation SVCSearchHeadView

@end
