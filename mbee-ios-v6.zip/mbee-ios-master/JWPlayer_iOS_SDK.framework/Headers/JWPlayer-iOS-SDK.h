//
//  JWPlayer_iOS_SDK_Dynamic.h
//  JWPlayer-iOS-SDK-Dynamic
//
//  Created by Anton Holub on 11/28/17.
//  Copyright © 2017 JWPlayer. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for JWPlayer_iOS_SDK_Dynamic.
FOUNDATION_EXPORT double JWPlayer-iOS-SDKVersionNumber;

//! Project version string for JWPlayer_iOS_SDK_Dynamic.
FOUNDATION_EXPORT const unsigned char JWPlayer-iOS-SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JWPlayer_iOS_SDK_Dynamic/PublicHeader.h>


