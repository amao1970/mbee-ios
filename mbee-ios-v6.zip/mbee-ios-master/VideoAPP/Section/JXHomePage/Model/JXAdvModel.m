//
//  JXAdvModel.m
//  MovieApp
//
//  Created by admxjx on 2019/4/19.
//

#import "JXAdvModel.h"

@implementation JXAdvModel

@end
