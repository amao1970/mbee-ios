//
//  SVCNovelCategoryModel.h
//  SmartValleyCloudSeeding
//
//  Created by 华安 on 2018/7/11.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SVCNovelCategoryModel : NSObject
@property(nonatomic, copy) NSString *ID; /**<<#属性#> */
@property(nonatomic, copy) NSString *title; /**<<#属性#> */
@property(nonatomic, copy) NSString *sort; /**<<#属性#> */


@end
