//
//  HMShowWebImgView.h
//  Hemefin_iOS
//
//  Created by admxjx on 2017/12/11.
//  Copyright © 2017年 Hemefin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMShowWebImgView : UIView

- (void)showBigImage:(NSArray *)imageUrls atIndex:(NSInteger )index title:(NSString*)title;

@end
