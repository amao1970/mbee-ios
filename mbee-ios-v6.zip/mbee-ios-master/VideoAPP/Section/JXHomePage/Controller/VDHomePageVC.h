//
//  VDHomePageVC.h
//  VideoAPP
//
//  Created by admxjx on 2019/5/6.
//  Copyright © 2019 SoWhat. All rights reserved.
//

#import "SVCBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface VDHomePageVC : SVCBaseViewController

@end

NS_ASSUME_NONNULL_END
