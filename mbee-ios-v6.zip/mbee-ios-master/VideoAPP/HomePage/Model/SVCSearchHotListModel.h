//
//  SVCSearchHotListModel.h
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2019/1/13.
//  Copyright © 2019 SoWhat. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SVCSearchHotListModel : NSObject

@property(nonatomic, copy) NSString *ID; /**<<#属性#> */
@property(nonatomic, copy) NSString *cate; /**<<#属性#> */
@property(nonatomic, copy) NSString *name; /**<<#属性#> */
@property(nonatomic, copy) NSString *pid; /**<<#属性#> */

@end

NS_ASSUME_NONNULL_END
