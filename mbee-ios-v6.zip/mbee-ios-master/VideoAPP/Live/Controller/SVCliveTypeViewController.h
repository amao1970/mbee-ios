//
//  SVCliveTypeViewController.h
//  SmartValleyCloudSeeding
//
//  Created by  on 2018/6/13.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVCliveTypeViewController : SVCBaseViewController

@property (nonatomic,copy) NSString *liveUrlStr;

@property (nonatomic,copy) NSString *titleStr;

@property (nonatomic,copy) NSString *imageStr;

@property (nonatomic ,copy)NSString *topTitle;

@end
