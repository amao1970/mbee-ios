//
//  SVCOnbordModel.m
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2018/11/22.
//  Copyright © 2018 SoWhat. All rights reserved.
//

#import "SVCOnbordModel.h"

@implementation SVCOnbordModel


+ (NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
