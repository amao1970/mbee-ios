//
//  SVCNovelDetailModel.h
//  SmartValleyCloudSeeding
//
//  Created by 华安 on 2018/7/12.
//  Copyright © 2018年 SoWhat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SVCNovelDetailModel : NSObject

@property(nonatomic, copy) NSString *title; /**<<#属性#> */

@property(nonatomic, copy) NSString *content; /**<<#属性#> */

@end
