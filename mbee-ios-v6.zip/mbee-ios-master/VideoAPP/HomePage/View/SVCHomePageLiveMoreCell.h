//
//  SVCHomePageLiveMoreCell.h
//  SmartValleyCloudSeeding
//
//  Created by admxjx on 2018/12/7.
//  Copyright © 2018 SoWhat. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SVCHomePageLiveMoreCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *img;

@end

NS_ASSUME_NONNULL_END
